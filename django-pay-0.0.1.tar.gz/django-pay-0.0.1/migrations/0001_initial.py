# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Product',
            fields=[
                ('uid', models.CharField(primary_key=True, serialize=False, max_length=64)),
                ('name', models.CharField(max_length=128)),
                ('price_net', models.FloatField()),
                ('price_total', models.FloatField()),
                ('vat_rate', models.FloatField(default=0.23)),
            ],
        ),
    ]
