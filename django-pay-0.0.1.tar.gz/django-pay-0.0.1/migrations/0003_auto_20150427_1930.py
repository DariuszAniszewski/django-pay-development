# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('payments', '0002_product_pkwiu_code'),
    ]

    operations = [
        migrations.CreateModel(
            name='Payment',
            fields=[
                ('uid', models.CharField(serialize=False, primary_key=True, max_length=64)),
                ('quantity', models.IntegerField(default=1)),
                ('status', models.CharField(max_length=16, choices=[('new', 'New'), ('started', 'Started'), ('failed', 'Failed'), ('completed', 'Completed')])),
                ('creation_timestamp', models.DateTimeField(auto_now_add=True)),
                ('modification_timestamp', models.DateTimeField(auto_now=True)),
            ],
        ),
        migrations.AlterField(
            model_name='product',
            name='uid',
            field=models.CharField(max_length=64, serialize=False, primary_key=True, help_text='Will be auto-generated'),
        ),
        migrations.CreateModel(
            name='PayuPayment',
            fields=[
                ('payment_ptr', models.OneToOneField(to='payments.Payment', primary_key=True, serialize=False, auto_created=True, parent_link=True)),
                ('payu_id', models.CharField(max_length=128, blank=True, null=True)),
            ],
            bases=('payments.payment',),
        ),
        migrations.AddField(
            model_name='payment',
            name='product',
            field=models.ForeignKey(to='payments.Product'),
        ),
        migrations.AddField(
            model_name='payment',
            name='user',
            field=models.ForeignKey(to=settings.AUTH_USER_MODEL),
        ),
    ]
